package com.example.recyclerpetagram;

import android.content.Context;

import java.util.ArrayList;

public class RecyclerViewFragmentPresenter implements InterfaceRecyclerViewFragmentPresenter{

    private InterfaceRecyclerViewFragmentView interfaceRecyclerViewFragmentView;
    private Context context;
    private ConstructorMascotas constructorMascotas;
    private ArrayList<Mascota> mascotas;

    public RecyclerViewFragmentPresenter (InterfaceRecyclerViewFragmentView interfaceRecyclerViewFragmentView, Context context){
        this.interfaceRecyclerViewFragmentView = interfaceRecyclerViewFragmentView;
        this.context = context;
        obtenerMascotasBD();
    }

    @Override
    public void obtenerMascotasBD() {
        constructorMascotas = new ConstructorMascotas(context);
        mascotas = constructorMascotas.obtenerDatos();
        mostrarMascotasRV();
    }

    @Override
    public void mostrarMascotasRV() {
        interfaceRecyclerViewFragmentView.inicializarAdaptadorRecyclerView(interfaceRecyclerViewFragmentView.crearAdaptador(mascotas));
        interfaceRecyclerViewFragmentView.generarLinearLayoutVertical();
    }
}
