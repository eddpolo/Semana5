package com.example.recyclerpetagram;

public interface InterfaceRecyclerViewFragmentPresenter {

    public void obtenerMascotasBD();

    public void mostrarMascotasRV();
}
