package com.example.recyclerpetagram;

import java.util.ArrayList;

public interface InterfaceRecyclerViewFragmentView {

    public void generarLinearLayoutVertical ();

    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas);

    public void inicializarAdaptadorRecyclerView(MascotaAdaptador adaptador);
}
