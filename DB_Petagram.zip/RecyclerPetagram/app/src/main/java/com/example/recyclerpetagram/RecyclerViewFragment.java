package com.example.recyclerpetagram;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewFragment extends Fragment implements InterfaceRecyclerViewFragmentView{

    //ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    private InterfaceRecyclerViewFragmentPresenter presenter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_recyclerview,container,false);
        listaMascotas   = (RecyclerView) v.findViewById(R.id.rvMascotas);
        presenter = new RecyclerViewFragmentPresenter(this,getContext());
        return v;
        //return super.onCreateView(inflater, container, savedInstanceState);
    }

//    public void inicializaAdaptador(){
//
//
//    }

//    public void inicializaListaMascotas(){
//
//        mascotas = new ArrayList<Mascota>();
//        mascotas.add(new Mascota(R.drawable.ic_chihuahua,"chihua", likes));
//        mascotas.add(new Mascota(R.drawable.ic_doggy,"doggy", likes));
//        mascotas.add(new Mascota(R.drawable.ic_manchas,"manchas", likes));
//        mascotas.add(new Mascota(R.drawable.ic_orejas,"orejas", likes));
//    }

    @Override
    public void generarLinearLayoutVertical() {
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        listaMascotas.setLayoutManager(llm);
    }

    @Override
    public MascotaAdaptador crearAdaptador(ArrayList<Mascota> mascotas) {
        MascotaAdaptador adaptador = new MascotaAdaptador(mascotas,getActivity());
        return adaptador;
    }

    @Override
    public void inicializarAdaptadorRecyclerView(MascotaAdaptador adaptador) {
        listaMascotas.setAdapter(adaptador);
    }
}
